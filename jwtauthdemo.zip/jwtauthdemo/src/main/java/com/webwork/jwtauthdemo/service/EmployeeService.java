package com.webwork.jwtauthdemo.service;

import java.util.List;

import com.webwork.jwtauthdemo.entity.Employee;

public interface EmployeeService {

	List<Employee> findAll();

}
